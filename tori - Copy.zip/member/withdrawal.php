<?php
session_start();
error_reporting(0);
if($_SESSION['login'] ==""){
	$_SESSION['alert'] = 'accdenied';
	header('Location:../index.php');
}
include 'template/head.php';
?>

<script type="text/javascript">

	$(document).ready(function() {
		var dataTable = $('#listtransaksi-grid').DataTable( {
			"processing": true,
			"serverSide": true,
			"ajax":{
				url :"../data/listsaldo.php", 
				type: "post", 
				error: function(){  
					$(".listtransaksi-grid-error").html("");
					$("#listtransaksi-grid").append('<tbody class="listtransaksi-grid-error"><tr><th colspan="5">Data kosong</th></tr></tbody>');
					$("#listtransaksi-grid_processing").css("display","none");		
				}
			},
			"language": {
				"url": "http://cdn.datatables.net/plug-ins/1.10.9/i18n/Indonesian.json",
				"sEmptyTable": "Tidak ada data di database"
			}
		} );
	} );

</script>

<div style="margin-top: 50px;padding: 10px;border-bottom: 3px solid #eee;" class="container container-top" id="listtrx">
	<form id="frm-wtrwl" action="../helper/lapak.php?aksi=savelapak" method="POST" style="overflow: hidden;height: auto">
	<div class="column-12" style="padding: 0px;margin-top: -10px">
			<div class="column-5" style="padding: 0px;">
				<h2 style="margin: 0px">Tarik Saldo</h2>

			</div>
			<div class="column-1" style="padding: 0px;text-align: center;">
				<span></span>
			</div>
			<div class="column-6" style="padding: 0px;margin-top: -3px;float: right;text-align: right;">
				<h5 style="margin: 0px;">Saldo Kamu</h5>
				<h5 style="margin: 0px;"">Rp.99999999</h5>
			</div>
		</div>
		<hr style="margin-top: 15px;">
		<div style=" text-align: left; padding: 0px 5px;">

			<div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="column-12">
						<div class="column-5" style="padding: 0px;">
							<label >Jumlah Saldo :</label>
							<input class="kb-input" type="text" name="jmlhsaldo" id="jmlhsaldo" placeholder="Jumlah Saldo">
						</div>
						<div class="column-2" style="padding: 0px;text-align: center;">
							<span></span>
						</div>
						<div class="column-5" style="padding: 0px;">
							<label >Atas Nama :</label>
							<input class="kb-input" type="text" name="jmlhsaldo" id="jmlhsaldo" placeholder="Jumlah Saldo">
						</div>
					</div>
				</div>
				<div class="row" style="margin-bottom: 10px;">
					<div class="column-12">
						<div class="column-5" style="padding: 0px;">
							<label>Bank :</label>
							<input class="kb-input" type="text" name="jmlhsaldo" id="jmlhsaldo" placeholder="Jumlah Saldo">
						</div>
						<div class="column-2" style="padding: 0px;text-align: center;margin-top: 10px;">
							<span></span>
						</div>
						<div class="column-5" style="padding: 0px;">
							<label>No Rekening :</label>
							<input class="kb-input" type="text" name="jmlhsaldo" id="jmlhsaldo" placeholder="Jumlah Saldo">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="column-12" style="margin-bottom: 10px;margin-top: 20px;">
						<input name="submit" class="kb-button  button-float kb-button2" style="width: 100%;cursor: pointer;" value="Simpan" type="submit">
					</div>
				</div>
			</div>
		</div>
	</form>

	<div class="search-content" style="background: #fff;padding: 0px 10px;" >
		<h3 style="padding-top: 10px">Riwayat Tarik Tunai</h3>
		<hr>
		<div style="width: 100%;overflow: auto;">
			<table id="listtransaksi-grid"  cellpadding="0" cellspacing="0" border="0" class="display" width="100%" >
				<thead>
					<tr>
						<th>Tanggal</th>
						<th>Keterangan</th>
						<th>Jumlah Saldo</th>
						<th>Status</th>
					</tr>
				</thead>
			</table>
		</div>
	</div>
</div>
<?php
include 'template/footer2.php';
?>
