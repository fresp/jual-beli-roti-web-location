<?php
date_default_timezone_set('Asia/Jakarta');	
// buat class member
class saldo {
	public function __construct() {
		require_once $_SERVER['DOCUMENT_ROOT'].'/config/database.php';	
	}
	function data(){
		$memid =$_SESSION['iduser'];
		$db = new database();		
		$mysqli = $db->connect();
		$sql = "SELECT sum(sld_amount) as amount FROM saldo WHERE mem_id LIKE '$memid' and sld_status like 'debit'";
		$result = $mysqli->query($sql);
		$row= $result->fetch_array();
		if($row[0]!=NULL){
			$angka = $row['amount'];
			$jumlah_desimal ="0";
			$pemisah_desimal =",";
			$pemisah_ribuan =".";
			echo "".number_format($angka, $jumlah_desimal, $pemisah_desimal, $pemisah_ribuan);
		}else{
			echo "0";
		}
	}
	function datawithdrawal(){
		$memid =$_SESSION['iduser'];
		$db = new database();		
		$mysqli = $db->connect();
		$sql = "SELECT sum(wdr_amount) as amount FROM withdrawal w INNER JOIN saldo s ON s.sld_id=w.sld_id WHERE s.mem_id LIKE '$memid'";
		$result = $mysqli->query($sql);
		$row= $result->fetch_array();
		if($row[0]){
			?>
			<p>Saldo Kamu : Rp.<?php echo $row['amount']?></p>
			<?php
		}else{
			?>
			<p>Saldo Kamu : Rp.0</p>
			<?php
		}
	}
}
?>
