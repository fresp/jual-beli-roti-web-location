<?php
$config['base_url'] = 'http://warungmodern.co/';
$config['db_url'] = 'http://warungmodern.co/config/database.php';
?>