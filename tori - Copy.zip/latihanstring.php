<?php
        $fields_string  =   "";
        $fields     =   array(
                            'api_key'       =>  '1ace21c0',
                            'api_secret'    =>  '5b1a9b1b5e315363',
                            'to'            =>  '+6281212213427',
                            'from'          =>  "Warung Modern",
                            'text'          =>  "[WM] Silahkan Segera selesaikan pembelian kamu\nInvoice : #3123123\nTotal Bayar : Rp.200000\nPembayaran : BCA\nTerimakasih
"
        );
        $url        =   "https://rest.nexmo.com/sms/json";

        //url-ify the data for the POST
	foreach($fields as $key=>$value) { 
            $fields_string .= $key.'='.$value.'&'; 
            }
	rtrim($fields_string, '&');

		//open connection
	$ch = curl_init();

	//set the url, number of POST vars, POST data
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_POST, count($fields));
	curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

	//execute post
	$result = curl_exec($ch);
	//close connection
	curl_close($ch);

        echo "<pre>";
        print_r($result); 
        echo "</pre>";
?>