<?php
session_start();
echo $lat2 = $_SESSION['lat'];
echo "<br>";
echo $long2 = $_SESSION['lon'];
?>